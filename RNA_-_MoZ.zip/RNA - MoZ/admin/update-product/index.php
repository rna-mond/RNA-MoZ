<?php
include("../../functions/rna_con");
if(isset($_POST['update'])){
	$pcode=$_POST['productcode'];
	$pname=$_POST['productname'];
	$pprice=$_POST['productprice'];
	$pbrand=$_POST['productbrand'];
	$pdesc=$_POST['productdescription'];
	$pquantity=$_POST['productquantity'];
	
	if ($pcode=="" || $pname=="" || $pprice=="" || $pbrand=="" || $pquantity==""){
		setcookie("error","Some fields are empty.",time()+120,"/");
		if(!empty($pcode)){setcookie("code",$pcode,time()+120,"/");}
		if(!empty($pname)){setcookie("name",$pname,time()+120,"/");}
		if(!empty($pprice)){setcookie("price",$pprice,time()+120,"/");}
		if(!empty($pbrand)){setcookie("brand",$pbrand,time()+120,"/");}
		if(!empty($pdesc)){setcookie("desc",$pdesc,time()+120,"/");}
		if(!empty($pquantity)){setcookie("quantity",$pquantity,time()+120,"/");}
		header('Location: ../product.php?update=$pcode');
	}else{
		if($_FILES["file"]["name"]==""){
			$update_data_only="UPDATE products SET product_name='$pname', product_price='$pprice',
											product_brand='$pbrand',product_description='$pdesc',
											product_quantity='$pquantity' WHERE product_code='$pcode'";
			$run=mysqli_query($conn,$update_data_only);
			if($run){
				setcookie("success","Product has been successfully updated!",time()+60,"/");
				header('Location: ../product.php?update='.$pcode);
			}
		}else{
			if ((($_FILES["file"]["type"] == "image/png")|| ($_FILES["file"]["type"] == "image/jpg")
				|| ($_FILES["file"]["type"] == "image/jpeg")|| ($_FILES["file"]["type"] == "image/gif")
				)&& ($_FILES["file"]["size"] < 10000000)){
				if ($_FILES["file"]["error"] > 0){
					echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
				}else{
					$_FILES["file"]["name"]=$pcode;
					$snum = $pcode;
						$ppic = $snum;
						$upload_avatar="UPDATE products SET product_name='$pname', product_price='$pprice',
												product_brand='$pbrand',product_description='$pdesc',
												product_quantity='$pquantity' WHERE product_code='$pcode'";
						$run=mysqli_query($conn,$upload_avatar);
						if($run){
							if(unlink ("../../products/$pcode")){
								move_uploaded_file($_FILES["file"]["tmp_name"],"../../products/" .$ppic);
								setcookie("success","Product has been successfully updated!",time()+60,"/");
								header('Location: ../product.php?update='.$pcode);
							}
						}
				}
			}else{
				setcookie("error","Failed to Update selected Product. Please try Again!",time()+120,"/");
				if(!empty($pcode)){setcookie("code",$pcode,time()+120,"/");}
				if(!empty($pname)){setcookie("name",$pname,time()+120,"/");}
				if(!empty($pprice)){setcookie("price",$pprice,time()+120,"/");}
				if(!empty($pbrand)){setcookie("brand",$pbrand,time()+120,"/");}
				if(!empty($pdesc)){setcookie("desc",$pdesc,time()+120,"/");}
				if(!empty($pquantity)){setcookie("quantity",$pquantity,time()+120,"/");}
				header('Location: ../product.php?update='.$pcode);
			}
		}
	}
}
?>