<?php
	include("../../functions/rna_con");
	$pcode = $_GET['del'];
	$del_product="DELETE FROM products WHERE product_code='$pcode'";
	if((mysqli_query($conn,$del_product))&&(unlink ("../../products/$pcode"))){
		header("Location: ../product.php?del&success=$pcode");
	}else{
		header("Location: ../product.php?del&error=$pcode");
	}
?>