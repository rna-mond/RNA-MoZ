<?php require("../functions/admin_session_checker");?>
<!DOCTYPE HTML>
<html>
<head>
<title>RNA - MoZ | Products</title>
<?php require("parts/head-links");?>
</head>
<body>	
<div class="page-container sidebar-collapsed">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<?php require("parts/header");?>
<!--inner block start here-->
<div class="inner-block">
    <div class="product-block">
    	<div class="pro-head">
    		<h2>Products</h2>
			<div id="prod-nav">
				<a href="?add-new"><button id="add-btn"><span class="fa fa-plus"></span> ADD NEW PRODUCT</button></a>
				<form  id="search" action="" method="get" enctype="multipart/form-data">
					<span class="fa fa-search"></span>
					<input onfocus="this.select();" id="s-search" <?php if(isset($_GET['search'])){echo 'value="'.$_GET['search'].'"';}?> autocomplete="off" type="search" placeholder="Search Products" name="search" autofocus>
				</form>
			</div>
    	</div>
		<?php
			if(isset($_GET['search'])&&$_GET['search']!=""){
				$sprod = $_GET['search'];
				$opt = "WHERE product_name LIKE '%$sprod%' OR product_brand LIKE '%$sprod%'";
			}else{
				$opt = "";
			}
			$prod_query = "SELECT * FROM products $opt ORDER BY product_dateadded ASC";
			include("../functions/rna_con");
			$run_pq = mysqli_query($conn,$prod_query);
			$prod_count = mysqli_num_rows($run_pq); 
			while($pdata = mysqli_fetch_array($run_pq)){
		?>
    	<div class="col-md-3 product-grid">
    		<div class="product-items" style="border:2px solid #337AB7;">
				<div style="padding: 2px 10px;background: #337AB7;font-weight: bold;">
					<a href="?del=<?php echo $pdata['product_code'];?>" style="color: rgba(255,150,150,1.0);"><span class="fa fa-trash"></span> DELETE</a> 
					<a href="?update=<?php echo $pdata['product_code'];?>" style="float: right;color: rgba(150,150,255,1.0);"><span class="fa fa-refresh"></span> UPDATE</a>
				</div>
				<?php
				date_default_timezone_set('Asia/Manila');
				if(substr($pdata['product_dateadded'],0,12)==date("M d, Y")){?>
					<div id="new-item"></div>
	    		<?php }?>
				<div class="project-eff">
					<img class="img-responsive" src="../products/<?php echo $pdata['product_code']?>" alt="">
				</div>
				<div class="produ-cost">
	    			<h4><?php echo $pdata['product_name']?></h4><hr style="margin: 0 auto;">
					<p style="color: lightgreen;"><?php echo $pdata['product_description']?></p><hr style="margin: 0 auto;">
	    			<h5 style="text-align: center;font-size: 20px;">P<?php echo $pdata['product_price']?>.00</h5><hr style="margin: 0 auto;">
					<p><b>QTY: </b><?php echo $pdata['product_quantity']-$pdata['product_sold'];?>&nbsp;<b>SOLD: </b><?php echo $pdata['product_sold']?></p>
					<hr style="margin: 0 auto;"><i style="font-size: 12px;color: lightgrey;"><b>DATE ADDED: </b><?php echo $pdata['product_dateadded'];?></i>
				</div>
    		</div>
    	</div>
			<?php }
				if($prod_count==0){?>
					<div class="col-md-12" style="text-align: center; background: orange;padding: 10px; color: white;">
						<h1><span class="fa fa-search"></span> NO ITEMS TO SHOW</h1>
					</div>
			<?php } ?>
      <div class="clearfix"> </div>
    </div>
</div>
<!--inner block end here-->
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
			<script type="text/javascript" src="js/nivo-lightbox.min.js"></script>
				<script type="text/javascript">
				$(document).ready(function(){
				    $('#nivo-lightbox-demo a').nivoLightbox({ effect: 'fade' });
				});
				</script>

<!--copy rights start here-->
<?php include("parts/footer");?>
</div>
</div>
<!--slider menu-->
<?php require("parts/navbar");?>
<!-- mother grid end here-->
<?php if(isset($_GET['add-new'])){ ?>
<div id="add-frm">
	<form action="add-new-product/" method="post" enctype="multipart/form-data">
		<h1><span class="fa fa-edit"></span> ADD NEW PRODUCT</h1>
		<?php if(isset($_COOKIE['error'])){?>
			<p style="background: rgba(255,0,0,0.5); color: white;"><span class="fa fa-info-circle"></span> <?php echo $_COOKIE['error'];?></p>
		<?php }elseif(isset($_COOKIE['success'])){?>
			<p style="background: rgba(0,255,0,0.5); color: white;"><span class="fa fa-info-circle"></span> <?php echo $_COOKIE['success'];?></p>
		<?php }?>
		<label for="file">Product Image:</label>
		<input type="file" name="file" required=""/>
		<input value="<?php if(isset($_COOKIE['code'])){echo $_COOKIE['code'];}?>" maxlength="30" class="form-control" placeholder="Product Code" name="productcode" type="text"  autofocus>
		<input value="<?php if(isset($_COOKIE['name'])){echo $_COOKIE['name'];}?>" maxlength="30" class="form-control" placeholder="Product Name" name="productname" type="text">
		<input value="<?php if(isset($_COOKIE['price'])){echo $_COOKIE['price'];}?>" maxlength="30" class="form-control" placeholder="Product Price (0.00)" name="productprice" type="text">
		<input value="<?php if(isset($_COOKIE['brand'])){echo $_COOKIE['brand'];}?>" maxlength="30" class="form-control" placeholder="Product Brand" name="productbrand" type="text">
		<textarea  maxlength="300" class="form-control" placeholder="Product Desciption" name="productdescription" type="text" style="height: 105px;"><?php if(isset($_COOKIE['desc'])){echo $_COOKIE['desc'];}?></textarea>
		<input value="<?php if(isset($_COOKIE['quantity'])){echo $_COOKIE['quantity'];}?>" maxlength="30" class="form-control" placeholder="Product Quantity" name="productquantity" type="text"><hr>
		<input type="submit" value="SAVE" name="save">
		<a href="product.php">CANCEL</a>
	</form>
</div>
<?php } 
	if(isset($_GET['del'])){?>
		<div id="del-frm">
			<div id="del-content">
				<h1><span class="fa fa-info-circle"></span> MESSAGE<a href="product.php" class="fa fa-close" style="float: right;margin-right: -30px; color: lightgreen;"></a></h1>
			<?php if(isset($_GET['del']) && $_GET['del']!=""){ ?>
				<p>Are you sure, you want to delete that '<?php echo $_GET['del'];?>' from the database?</p>
				<hr style="border: 1px solid green;">
				<a href="delete-product/?del=<?php echo $_GET['del'];?>"><button class="btn-yes">YES</button></a>
				<a href="product.php"><button class="btn-no">NO</button></a>
			<?php }elseif(isset($_GET['success'])){ ?>
				<p><?php echo $_GET['success'];?> has been deleted successfully.</p>
				<hr style="border: 1px solid green;">
				<a href="product.php"><button class="btn-yes">OK</button></a>
			<?php }elseif(isset($_GET['error'])){ ?>
				<p style="color: red;">Failed to delete '<?php echo $_GET['error'];?>' from the database?</p>
				<hr style="border: 1px solid green;">
				<a href="product.php"><button class="btn-yes">OK</button></a>
			<?php }?>
			</div>
		</div>
	<?php }
	if(isset($_GET['update'])&& $_GET['update']!=""){?>
		<div id="add-frm">
	<form action="update-product/" method="post" enctype="multipart/form-data">
		<h1><span class="fa fa-refresh"></span> UPDATE PRODUCT</h1>
		<?php if(isset($_COOKIE['error'])){?>
			<p style="background: rgba(255,0,0,0.5); color: white;"><span class="fa fa-info-circle"></span> <?php echo $_COOKIE['error'];?></p>
		<?php }elseif(isset($_COOKIE['success'])){?>
			<p style="background: rgba(0,255,0,0.5); color: white;"><span class="fa fa-info-circle"></span> <?php echo $_COOKIE['success'];?></p>
		<?php }
			$sel_prod = $_GET['update'];
			$sprod = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM products WHERE product_code='$sel_prod'"));
		?>
		<div id="up-img" style="background-image: url('../products/<?php echo $sprod['product_code'];?>');"><p>Current Image</p></div>
		<label for="file">Change Product Image:</label>
		<input type="file" name="file"/>
		<input readonly value="<?php if(isset($_COOKIE['code'])){echo $_COOKIE['code'];}else{echo $sprod['product_code'];}?>" maxlength="30" class="form-control" placeholder="Product Code" name="productcode" type="text">
		<input value="<?php if(isset($_COOKIE['name'])){echo $_COOKIE['name'];}else{echo $sprod['product_name'];}?>" maxlength="30" class="form-control" placeholder="Product Name" name="productname" type="text" autofocus>
		<input value="<?php if(isset($_COOKIE['price'])){echo $_COOKIE['price'];}else{echo $sprod['product_price'];}?>" maxlength="30" class="form-control" placeholder="Product Price (0.00)" name="productprice" type="text">
		<input value="<?php if(isset($_COOKIE['brand'])){echo $_COOKIE['brand'];}else{echo $sprod['product_brand'];}?>" maxlength="30" class="form-control" placeholder="Product Brand" name="productbrand" type="text">
		<textarea  maxlength="300" class="form-control" placeholder="Product Desciption" name="productdescription" type="text" style="height: 50px;"><?php if(isset($_COOKIE['desc'])){echo $_COOKIE['desc'];}else{echo $sprod['product_description'];}?></textarea>
		<input value="<?php if(isset($_COOKIE['quantity'])){echo $_COOKIE['quantity'];}else{echo $sprod['product_quantity'];}?>" maxlength="30" class="form-control" placeholder="Product Quantity" name="productquantity" type="text"><hr>
		<input type="submit" value="UPDATE" name="update">
		<a href="product.php">CANCEL</a>
	</form>
</div>
	<?php }?>
</body>
</html>