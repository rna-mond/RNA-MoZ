<?php require("../functions/admin_session_checker");?>
<!DOCTYPE HTML>
<html>
<head>
	<title>RNA - MoZ | Admin Dashboard</title>
	<?php require("parts/head-links");?>
</head>
<body>	
<div class="page-container sidebar-collapsed">	
   <div class="left-content">
	   <div class="mother-grid-inner">
		<?php require("parts/header");?>
<!--heder end here-->
<!--inner block start here-->
<div class="inner-block">
<!--market updates updates-->
	 <div class="market-updates">
			<div class="col-md-4 market-update-gd">
				<div class="market-update-block clr-block-1">
					<div class="col-md-8 market-update-left">
					<?php include("../functions/rna_con");
						$sel_users = "SELECT * FROM users";
						$reg_count = mysqli_num_rows(mysqli_query($conn,$sel_users));
					?>
						<h3><?php echo $reg_count;?></h3>
						<h4>Registered User</h4>
					</div>
					<div class="col-md-4 market-update-right">
						<i class="fa fa-file-text-o"> </i>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-4 market-update-gd">
				<div class="market-update-block clr-block-2">
				 <div class="col-md-8 market-update-left">
					<?php date_default_timezone_set('Asia/Manila');
							$cdate = date("M d, Y");
						$sel_logs = "SELECT * FROM users_logs WHERE log_date='$cdate' AND log_status='Login'";
						$logs_count = mysqli_num_rows(mysqli_query($conn,$sel_logs));
					?>
					<h3><?php echo $logs_count;?></h3>
					<h4>Daily Visitors</h4>
				  </div>
					<div class="col-md-4 market-update-right">
						<i class="fa fa-eye"> </i>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-4 market-update-gd">
				<div class="market-update-block clr-block-3">
					<div class="col-md-8 market-update-left">
					<?php 
						$sel_sold = "SELECT SUM(product_sold) FROM products";
						$sold = mysqli_fetch_array(mysqli_query($conn,$sel_sold));
					?>
						<h3><?php echo $sold[0];?></h3>
						<h4>Total Sold Items</h4>
					</div>
					<div class="col-md-4 market-update-right">
						<i class="fa fa-money"> </i>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
		   <div class="clearfix"> </div>
		</div>
<!--market updates end here-->
<!--mainpage chit-chating-->
<div class="chit-chat-layer1">
	<div class="col-md-6 chit-chat-layer1-left">
               <div class="work-progres">
                            <div class="chit-chat-heading">
                                  Top 10 Active Users
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                  <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>USERNAME</th>
                                      <th>COMPLETE NAME</th>                                   
                                                                        
                                      <th>LOGINS</th>
                                      <th>SPENDED</th>
                                  </tr>
                              </thead>
                              <tbody>
								<?php
									$num = 0;
									$sel_data = mysqli_query($conn,"SELECT users.userid,users.username,user_details.firstname,user_details.middlename,user_details.lastname FROM users,user_details WHERE users.userid=user_details.userid AND users.account_type='USER' LIMIT 10");
									while($tdata = mysqli_fetch_array($sel_data)){
											$num++;
											$luname = $tdata['username'];
											$luid = $tdata['userid'];
											$logs_data = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE username='$luname' AND log_status='Login'"));
										$order_sum = mysqli_fetch_array(mysqli_query($conn,"SELECT SUM(users_order.order_total) FROM users_order WHERE userid='$luid' ORDER BY order_total ASC"));
										$o_total = $order_sum[0];
								?>
                                <tr>
                                  <td><?php echo $num;?></td>
                                  <td><?php echo $luname;?></td>
                                  <td><?php echo $tdata['firstname'].' '.$tdata['middlename'].' '.$tdata['lastname'];?></td>                                 
                                                             
                                  <td align="center"><span class="badge"><?php echo $logs_data;?></span></td>
                                  <td align="center"><span class="badge"><?php if($o_total!=0){echo 'P'.$o_total.'.00';}else{echo 'P0.00';}?></span></td>
								</tr>
								<?php }?>
                          </tbody>
                      </table>
                  </div>
             </div>
      </div>
      <div class="col-md-6 chart-blo-1">
    	    <div class="line-chart">
    		<h3>USERS MONTHLY LOGS STATISTICS</h3>
			<?php
				$year = date("Y");
				$Jan = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Jan%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Feb = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Feb%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Mar = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Mar%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Apr = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Apr%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$May = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%May%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Jun = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Jun%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Jul = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Jul%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Aug = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Aug%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Sep = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Sep%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Oct = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Oct%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Nov = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Nov%' AND log_date LIKE '%$year%' AND log_status='Login'"));
				$Dec = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users_logs WHERE log_date LIKE '%Dec%' AND log_date LIKE '%$year%' AND log_status='Login'"));
			?>
    		 <canvas id="line" height="300" width="400" style="width: 400px; height: 300px;"> </canvas>
                    <script>
                        var barChartData = {
						labels : ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
						datasets : [
							{
								fillColor : "rgba(0, 255, 0, 0.5)",
								strokeColor : "green",
								pointColor : "#FC8213",
								pointStrokeColor : "#fff",
								data : [<?php echo $Jan;?>,<?php echo $Feb;?>,<?php echo $Mar;?>,<?php echo $Apr;?>,
										<?php echo $May;?>,<?php echo $Jun;?>,<?php echo $Jul;?>,<?php echo $Aug;?>,
										<?php echo $Sep;?>,<?php echo $Oct;?>,<?php echo $Nov;?>,<?php echo $Dec;?>]
							}
						]
						
					};
                       new Chart(document.getElementById("line").getContext("2d")).Bar(barChartData);

                    </script>
    	    </div>
    	  </div>
     <div class="clearfix"> </div>
</div>
<!--main page chit chating end here-->
</div>
<!--inner block end here-->
<?php include("parts/footer");?>
</div>
</div>
<?php require("parts/navbar");?>
</body>
</html>                     