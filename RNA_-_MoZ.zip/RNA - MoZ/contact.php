<?php require("functions/session_checker");?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<?php require("parts/head-links");?>
	<title>RNA-MoZ | Categories</title>
  </head>
  <body>
   <?php
	include("parts/header");
   ?>
    <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2>CONTACT</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="col-md-12" style="background: white;">
			<div class="col-md-10" style="font-size: 20px;margin: 2% 8%;border-top: 10px solid green;border-bottom: 5px solid green;background: rgba(0,0,0,0.1);">
					<strong style=" margin: 5%; margin-top: 10px; font-size: 30px;"><span class="fa fa-mobile"></span> CALL or TEXT Me via</strong><hr style=" margin: 0 auto;border: 1px solid green;">
					<p style="margin-left: 10%; margin-top: 2%;" >(+63) 918 - 624 - 4972</p></br></br>
					<strong style=" margin: 5%; margin-top: 10px; font-size: 30px;"><span class="fa fa-envelope"></span> Or Send Me an Email via</strong><hr style=" margin: 0 auto;border: 1px solid green;">
					<a style="margin-left: 10%; margin-top: 2%;" href="mailto:raymondagusa7@gmail.com">raymondagusa7@gmail</a></br></br>
					<a style="margin-left: 10%; margin-top: 2%;" href="mailto:agusa.raymond@yahoo.com">agusa.raymond@yahoo.com</a></br></br>
					<a style="margin-left: 10%; margin-top: 2%;" href="http://www.facebook.com/raymond.agusa.73/message">raymond.agusa.73</a></br></br>
					<strong style=" margin: 5%; margin-top: 10px; font-size: 30px;"><span class="fa fa-home"></span> Or Directly visit me on my House</strong><hr style=" margin: 0 auto;border: 1px solid green;">
					<p style="margin-left: 10%; margin-top: 2%;" >P-3 Brgy. Sta. Cruz, Labo, Camarines Norte</p>
				</div>
			</div>
		</div>
		<div class="col-md-12" style="height: 20px;"></div>
    <?php include("parts/footer");?>
  </body>
</html>