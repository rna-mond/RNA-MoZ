<?php
error_reporting(0);
require 'class.phpmailer.php';



$mail = new PHPMailer();

$mail->IsSMTP();
$mail->SMTPDebug = 2;
$mail->Mailer = 'smtp';
$mail->SMTPAuth = true;
$mail->Host = 'smtp.gmail.com'; // "ssl://smtp.gmail.com" didn't worked
$mail->Port = 465;
$mail->SMTPSecure = 'ssl';
$mail->WordWrap = 50;
// or try these settings (worked on XAMPP and WAMP):
// $mail->Port = 587;
// $mail->SMTPSecure = 'tls';


$mail->Username = "joycemalubay@gmail.com";
$mail->Password = "franciamalubay";

$mail->IsHTML(true); // if you are going to send HTML formatted emails
$mail->SingleTo = true; // if you want to send a same email to multiple users. multiple emails will be sent one-by-one.

$mail->From = "joycemalubay@gmail.com";
$mail->FromName = "Joyce";

//$mail->addAddress("esor1008@gmail.com","Joyce"); //BCC1
$mail->addAddress("joycemalubay@gmail.com","Joyce"); //BCC1

//$mail->addCC("user.3@ymail.com","User 3");
//$mail->addBCC("user.4@in.com","User 4");

$mail->Subject = "Testing PHPMailer with localhost";
$mail->Body = "Hi,<br /><br />This system is working perfectly.";

if($mail->Send()){ echo "Send mail successfully";}
else{echo "Send mail fail";}
?>