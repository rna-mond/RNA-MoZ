-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2016 at 11:43 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_9f2a14_escl`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_mail`
--

CREATE TABLE IF NOT EXISTS `admin_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_add` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_mail`
--

INSERT INTO `admin_mail` (`id`, `email_add`, `password`) VALUES
(1, 'joycemalubay@gmail.com', 'franciamalubay');

-- --------------------------------------------------------

--
-- Table structure for table `announce_remind`
--

CREATE TABLE IF NOT EXISTS `announce_remind` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `detail` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `eventdate` varchar(20) NOT NULL,
  `dateadded` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `announce_remind`
--

INSERT INTO `announce_remind` (`id`, `title`, `detail`, `type`, `eventdate`, `dateadded`) VALUES
(30, 'title for reminders 1', 'details for reminders 1', 'Reminder', '01/26/2016', '2016-01-23 13:15:40'),
(31, 'title for reminders 2', 'details for reminders 2', 'Reminder', '01/26/2016', '2016-01-23 13:19:48'),
(32, 'announce_remind title 1', 'announce_remind detail 1', 'Announcement', '01/26/2016', '2016-01-24 07:03:02'),
(35, 'title 4 reminder', 'details 4 reminder', 'Reminder', '01/27/2016', '2016-01-24 08:43:44');

-- --------------------------------------------------------

--
-- Table structure for table `hosp_adform`
--

CREATE TABLE IF NOT EXISTS `hosp_adform` (
  `hosp_adformno` int(11) NOT NULL,
  `hospitalname` varchar(50) NOT NULL,
  `doctorname` varchar(50) NOT NULL,
  `p_lname` varchar(50) NOT NULL,
  `p_fname` varchar(50) NOT NULL,
  `p_mname` varchar(50) NOT NULL,
  `p_age` varchar(50) NOT NULL,
  `p_gender` varchar(50) NOT NULL,
  `p_status` varchar(50) NOT NULL,
  `streetname` varchar(50) NOT NULL,
  `subd_vil` varchar(50) NOT NULL,
  `purok` varchar(50) NOT NULL,
  `brgy` varchar(50) NOT NULL,
  `town` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `chief_complains` varchar(150) NOT NULL,
  `diagnosis` varchar(150) NOT NULL,
  `notes` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ap_id` varchar(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `email` varchar(1024) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `email_code` varchar(32) NOT NULL DEFAULT '0',
  `date` varchar(50) NOT NULL,
  `pagehits` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `ap_id`, `username`, `password`, `firstname`, `lastname`, `middlename`, `email`, `designation`, `active`, `email_code`, `date`, `pagehits`) VALUES
(57, 'ESCL-1', 'kj', '1', 'KAREN JOYCE', 'MARIANO', 'ALB', 'kj@gmail.com', 'PATIENT', 1, '047471c151b6f90ac3a4ffeaddadf03c', 'January 21, 2016', 7),
(59, 'ESCL-8', 'rose', '1', 'ROSELYN', 'RASCO', 'HERICO', 'rose@gmail.com', 'ADMIN', 1, 'a3160ad6806f87b6e31e834e8c94ca32', 'January 21, 2016', 1);

-- --------------------------------------------------------

--
-- Table structure for table `med_abstract`
--

CREATE TABLE IF NOT EXISTS `med_abstract` (
  `medabstractno` int(11) NOT NULL,
  `recipientname` varchar(50) NOT NULL,
  `agencyname` varchar(50) NOT NULL,
  `agencyaddress` varchar(50) NOT NULL,
  `p_lastname` varchar(50) NOT NULL,
  `p_firstname` varchar(50) NOT NULL,
  `p_middlename` varchar(50) NOT NULL,
  `p_age` varchar(50) NOT NULL,
  `p_gender` varchar(50) NOT NULL,
  `p_status` varchar(50) NOT NULL,
  `streetname` varchar(50) NOT NULL,
  `sub_village` varchar(50) NOT NULL,
  `purok` varchar(50) NOT NULL,
  `brgy` varchar(50) NOT NULL,
  `town` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `chief_complains` varchar(150) NOT NULL,
  `diagnosis` varchar(150) NOT NULL,
  `lab_examtaken` varchar(150) NOT NULL,
  `prescription` varchar(150) NOT NULL,
  `progress_note` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `med_certificates`
--

CREATE TABLE IF NOT EXISTS `med_certificates` (
  `medcertno` int(11) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `streetname` varchar(50) NOT NULL,
  `subd_village` varchar(50) NOT NULL,
  `purok` varchar(50) NOT NULL,
  `barangay` varchar(50) NOT NULL,
  `town` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient_condetails`
--

CREATE TABLE IF NOT EXISTS `patient_condetails` (
  `patientnum` int(11) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `chiefcomplains` varchar(150) NOT NULL,
  `diagnosis` varchar(150) NOT NULL,
  `prescribedmed` varchar(50) NOT NULL,
  `pieces` varchar(50) NOT NULL,
  `frequency` varchar(50) NOT NULL,
  `med_duration` varchar(50) NOT NULL,
  `labrequest` varchar(50) NOT NULL,
  `followup` varchar(50) NOT NULL,
  `followup_duration` varchar(50) NOT NULL,
  `followup_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient_geninfo`
--

CREATE TABLE IF NOT EXISTS `patient_geninfo` (
  `patientnumber` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(50) NOT NULL,
  `patientID` varchar(50) NOT NULL,
  `patienttype` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `extension` varchar(50) NOT NULL,
  `birthday` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `contactno` varchar(50) NOT NULL,
  `streetname` varchar(50) NOT NULL,
  `subdivision_village` varchar(50) NOT NULL,
  `purok` varchar(50) NOT NULL,
  `barangay` varchar(50) NOT NULL,
  `municipality` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `sencitno` varchar(50) NOT NULL,
  `guardian` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  PRIMARY KEY (`patientnumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `patient_geninfo`
--

INSERT INTO `patient_geninfo` (`patientnumber`, `date`, `patientID`, `patienttype`, `lastname`, `firstname`, `middlename`, `extension`, `birthday`, `age`, `gender`, `status`, `contactno`, `streetname`, `subdivision_village`, `purok`, `barangay`, `municipality`, `province`, `sencitno`, `guardian`, `contact`) VALUES
(1, '1/22/2016', 'ESCL-1', 'RELATIVES', 'MARIANO', 'KAREN JOYCE', 'ALB', 'NA', '01/07/1987', '28', 'FEMALE', 'SINGLE', '09054118971', 'ROSAS ST.', 'MANLAPAZ SUBDIVISION', 'PUROK 2', 'GUMAMELA', 'LABO', 'CN', 'NA', 'JOSE MALUBAY J.', '09054118971'),
(2, '1/22/2016', 'ESCL-8', 'RALATIVES', 'RASCO', 'ROSELYN', 'HERICO', 'NA', '10/8/1989', '27', 'FEMALE', 'SINGLE', '09054119871', 'ROSAS ST.', 'MANLAPAZ SUBDIVISION', 'PUROK 5', 'GUMAMELA', 'LABO', 'CN', 'NA', 'NA', '09054118971');

-- --------------------------------------------------------

--
-- Table structure for table `patient_vitals`
--

CREATE TABLE IF NOT EXISTS `patient_vitals` (
  `patientid` varchar(11) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `bloodpressure` varchar(50) NOT NULL,
  `cardiacrate` varchar(50) NOT NULL,
  `respiratoryrate` varchar(50) NOT NULL,
  `temperature` varchar(50) NOT NULL,
  `weight` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_vitals`
--

INSERT INTO `patient_vitals` (`patientid`, `lastname`, `firstname`, `middlename`, `bloodpressure`, `cardiacrate`, `respiratoryrate`, `temperature`, `weight`) VALUES
('ESCL-1', 'MARIANO', 'KJ', 'ALB', '56', '34', '23', '67', '42'),
('ESCL-1', 'ALBAN', 'HOHO', 'DDTD', '', '', '', '', ''),
('ESCL-2', 'ALBAN', 'JOYCE', 'GO', '23', '23', '44', '28', '44'),
('ESCL-2', 'ALBAN', 'JOYCE', 'GO', '56', '34', '32', '37', '54'),
('ESCL-2', 'ALBAN', 'JOYCE', 'GO', '23', '34', '56', '54', '34'),
('ESCL-2', 'ALBAN', 'JOYCE', 'GO', '34', '34', '65', '34', '52'),
('ESCL-6', 'ALBAN', 'KAREN', 'NINA', '32', '32', '32', '32', '32');

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE IF NOT EXISTS `referrals` (
  `referralnumber` int(11) NOT NULL,
  `referredto` varchar(50) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `p_lname` varchar(50) NOT NULL,
  `p_fname` varchar(50) NOT NULL,
  `p_mname` varchar(50) NOT NULL,
  `p_age` varchar(50) NOT NULL,
  `p_gender` varchar(50) NOT NULL,
  `p_status` varchar(50) NOT NULL,
  `streetname` varchar(50) NOT NULL,
  `subd_vil` varchar(50) NOT NULL,
  `purok` varchar(50) NOT NULL,
  `brgy` varchar(50) NOT NULL,
  `town` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `diagnosis` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ap_id` varchar(10) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `designation` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `ap_id`, `firstname`, `lastname`, `middlename`, `designation`) VALUES
(6, 'ESCL-1', 'KAREN JOYCE', 'MARIANO', 'ALB', 'PATIENT'),
(7, 'ESCL-8', 'ROSELYN', 'RASCO', 'HERICO', 'ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `idnum` int(11) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `extension` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `age` varchar(3) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `birthday` varchar(50) NOT NULL,
  `contactno` varchar(15) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `civilstatus` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `streetname` varchar(50) NOT NULL,
  `subvil` varchar(50) NOT NULL,
  `purok` varchar(50) NOT NULL,
  `barangay` varchar(50) NOT NULL,
  `municipality` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`idnum`, `lastname`, `firstname`, `middlename`, `extension`, `title`, `age`, `gender`, `birthday`, `contactno`, `religion`, `civilstatus`, `designation`, `streetname`, `subvil`, `purok`, `barangay`, `municipality`, `province`) VALUES
(1, 'KDHSK', 'HKHK', 'RYUJ', 'Jr.', 'UDF', '12', 'Female', '12/23/1998', '21', 'TAESY', '-Select-', 'SWND', 'GAKDGK', 'HKK', 'GKGKG', 'FH', 'FGJN,J', 'VJGYK'),
(1234, 'KGKK', 'TGBH', 'WERT', 'Jr.', 'FGJL', '34', 'Female', '11/23/1987', '34', 'ATWGTD', 'Female', 'HRYCMSK', 'YDUSD', 'THSY', 'TSWTN', 'TWCJZB', 'GSKBSG', 'XGKBSK'),
(343, 'NVN', '     XVXV', '', '', '', '', '', '  /  /', '', '', '', '', '', '', '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
