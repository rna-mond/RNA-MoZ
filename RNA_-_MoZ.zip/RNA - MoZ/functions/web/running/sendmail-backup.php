<html>
<head>



</head>

<body>
<?php
error_reporting(0);

if(isset($_POST['submit'])){
	
$message =
'Full Name : '.$_POST['fullname'].'<br />
Phone : '.$_POST['phone'].'<br />
Email : '.$_POST['emailid'].'<br />
Subject : '.$_POST['subject'].'<br />
Comments : '.$_POST['comments'].'';
	
	
require 'class.phpmailer.php';



$mail = new PHPMailer();

$mail->IsSMTP();
$mail->SMTPDebug = 2;
$mail->Mailer = 'smtp';
$mail->SMTPAuth = true;
$mail->Host = 'smtp.gmail.com'; // "ssl://smtp.gmail.com" didn't worked
$mail->Port = 465;
$mail->SMTPSecure = 'ssl';
$mail->WordWrap = 50;
// or try these settings (worked on XAMPP and WAMP):
// $mail->Port = 587;
// $mail->SMTPSecure = 'tls';


$mail->Username = "joycemalubay@gmail.com";
$mail->Password = "franciamalubay";

$mail->IsHTML(true); // if you are going to send HTML formatted emails
$mail->SingleTo = true; // if you want to send a same email to multiple users. multiple emails will be sent one-by-one.

$mail->From = $_POST['emailid'];
$mail->FromName = $_POST['fullname'];

//$mail->addAddress("esor1008@gmail.com","Joyce"); //BCC1
$mail->addAddress("joycemalubay@gmail.com","Joyce"); //BCC1

//$mail->addCC("user.3@ymail.com","User 3");
//$mail->addBCC("user.4@in.com","User 4");

$mail->Subject = $_POST['subject'];
$mail->Body = $message;

if($mail->Send()){ $errormsg = 'Successfully send';}
else{echo "Send mail fail";}

}


$form ="<form id ='form1' action ='' name='form1' id='form1' method = 'post' style='width: 500px;'>
			
			 
			 <fieldset>
				<legend>Send Mail </legend>

				<div id='list2'> <h3>$errormsg</h3></div>
				
				<div class='elements'>
				  <label for='name'>Sender Name :</label>
				  <input type='text' name='fullname' placeholder='Fullname'/>
				</div>
				
				<div class='elements'>
				  <label for='e-mail'>Phone No. :</label>
				  <input type='text' name='phone' placeholder='Phone'/>
				</div>
				
				<div class='elements'>
				  <label for='Password'>E-mail :</label>
				  <input type='text' name='emailid' placeholder='E-mail'/>
				</div>
				
				<div class='elements'>
				  <label for='Retypepassword'>Subject :</label>
				  <input type='text' name='subject' placeholder='Subject'/>
				</div>
				
				<div class='elements'>
				  <label for='apid'>Message :</label>
				  <textarea rows='4' cols'20' name='comments' placeholder='Comments'> </textarea>
				</div>
										
				<div class='submit'>
				  <input type='submit' name='submit' value='send' />
				</div>
				
			 </fieldset>
			
			
			</form>";
			
		echo $form;

?>
</body>
</html>