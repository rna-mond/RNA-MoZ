<?php

require 'db/connection.inc.php';
										
$queryName = mysql_query("SELECT * FROM admin_mail");

while ($row = mysql_fetch_object($queryName)){
	$email    = $row->email_add;
	$password =	$row->password;
}

echo md5($password);


?>