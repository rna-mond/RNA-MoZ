<?php
require 'db/connection.inc.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang = 'en'>
	<title>ESCL Website</title>
	<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<head>
<title>Doctor Plus a Medical Category Flat bootstrap Responsive website Template | About :: w3layouts</title>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/abouts.css" type="text/css" rel="stylesheet" media="all">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Doctor Plus Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Custom Theme files -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script> 
<!-- //js -->	
<!-- start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>	
<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
</script>
<!--//end-smoth-scrolling-->
</head>
<body>
	<!--header-->
	<div class="header">
		<div class="container">
			<div class="header-logo">
				<a href="index.html"><img src="images/logoNew-300px.png" alt="logo"/></a>					
			</div>
			<div class="header-info">
				<p>Information Service:</p>
				<h4>000-1234-1234</h4>
			</div>			
			<div class="clearfix"> </div>
		</div>	
	</div>
	<!--//header-->
	<!--header-bottom-->
	<div class="header-bottom">
		<div class="container">
			<!--top-nav-->
			<div class="top-nav cl-effect-5">
				<span class="menu-icon"><img src="images/menu-icon_new.png" alt=""/></span>		
				<ul class="nav1">
					<li><a href="index.php" ><span data-hover="Home">Home</span></a></li>
					<li><a class="active"> <span data-hover="About">About</span></a></li>
					<li><a href="services.php"> <span data-hover="Services">Services</span></a></li>
					<li><a href="contact.php"> <span data-hover="Contact">Contact</span></a></li>
					<li><a href="admin/login.php"> <span data-hover="Login">Login</span></a></li>
				</ul>
				<!-- script-for-menu -->
				<script>
				   $( "span.menu-icon" ).click(function() {
					 $( "ul.nav1" ).slideToggle( 300, function() {
					 // Animation complete.
					  });
					 });
				</script>
				<!-- /script-for-menu -->
			</div>
			<!--//top-nav-->
			<form class="navbar-form navbar-right">
				<div class="form-group">
					<input type="text" class="form-control" placeholder="Search">
					<button type="submit" class="btn btn-default"></button>
				</div>		
			</form>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--//header-bottom-->
	<!--about-->
	<div class="about"> 
		<div class="container">
			<h3>Who we are</h3>
			<div class="about-text">
				<div class="col-md-6 about-text-left">
					<img src="images/img4.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="col-md-6 about-text-right">
					<h4>Mission</h4>
					<p>The point of using content here'orem Ipsum whichbut the majority have  passage of Lorem Ipsum, you need   
						anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators making this the first true generato.</p>
					<p>The point of using Lorem Ipsum is that it has a more-or-less normal 'Content here, content here'orem Ipsum whichbut the majority have  passage of Lorem Ipsum, you need to be sure there isn't  
						anything embarrassing hidden in the middle of text</p>
					<h4>Vision</h4>
					<p>The point of using content here'orem Ipsum whichbut the majority have  passage of Lorem Ipsum, you need   
						anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators making this the first true generato.</p>
					<p>The point of using Lorem Ipsum is that it has a more-or-less normal 'Content here, content here'orem Ipsum whichbut the majority have  passage of Lorem Ipsum, you need to be sure there isn't  
						anything embarrassing hidden in the middle of text</p>
					<h4>Objectives</h4>
					<p>The point of using content here'orem Ipsum whichbut the majority have  passage of Lorem Ipsum, you need   
						anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators making this the first true generato.</p>
					<p>The point of using Lorem Ipsum is that it has a more-or-less normal 'Content here, content here'orem Ipsum whichbut the majority have  passage of Lorem Ipsum, you need to be sure there isn't  
						anything embarrassing hidden in the middle of text</p>
					<!--<ul>
						<li><a href="#">Donec ut quam andomised words lscelerisque.</a></li>
						<li><a href="#">Etiam volutpa andomised words tbh lobortis</a></li>
						<li><a href="#">Varius fusce vitaeb landitan domised words.</a></li>
					</ul>-->
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="about-slid"> 
			<div class="container">
				<div class="about-slid-info"> 
					<h2>Lorem Ipsum is that it has a moreless normal</h2>
					<p>Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet embarrassing hidden in the middle of text.</p>
				</div>
			</div>
		</div>
		<div class="about-team">
			<h3>Meet the heads</h3>
			<div class="container">
				<div class="row team-row">
					<div class="col-sm-6 col-md-3 team-grids">
						<div class="thumbnail team-thmnl">
							<img src="images/img5.jpg" alt="...">
							<div class="caption">
								<h4><a href="#">Full Name</a></h4>
								<p>Office Name</p>						
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3 team-grids">
						<div class="thumbnail team-thmnl">
							<img src="images/img6.jpg" alt="...">
							<div class="caption">
								<h4><a href="#">Full Name</a></h4>
								<p>Office Name</p>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3 team-grids">
						<div class="thumbnail team-thmnl">
							<img src="images/img7.jpg" alt="...">
							<div class="caption">
								<h4><a href="#">Full Name</a></h4>
								<p>Office Name</p>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3 team-grids">
						<div class="thumbnail team-thmnl">
							<img src="images/img8.jpg" alt="...">
							<div class="caption">
								<h4><a href="#">Full Name</a></h4>
								<p>Office Name</p>
							</div>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<div class="about-skills">
			<div class="container">
				<h3>Our specials</h3>
				<div class="about-choose">
					<div class="col-md-4 about-choose-info">
						<h4>Certifications</h4>
						<ul>
							<li><a href="#">Donec ut quam ligula feugiat scelerisque.</a></li>
							<li><a href="#">Etiam volutpat tortor quis nibh lobortis</a></li>
							<li><a href="#">Fusce vitae dolor vitae blandit varius.</a></li>
							<li><a href="#">Proin commodo metus sed nisi lobortis.</a></li>
							<li><a href="#">Nunc volutpat neque vel augue interdum,</a></li>
							<li><a href="#">condimentum fringilla justo lobortis.</a></li>
							<li><a href="#">Vivamus consequat dolor ac est congue.</a></li>
						</ul>
					</div>
					<div class="col-md-4 about-choose-info">
						<h4>Our skills</h4>
						<ul>
							<li><a href="#">Donec ut quam ligula feugiat scelerisque.</a></li>
							<li><a href="#">Etiam volutpat tortor quis nibh lobortis</a></li>
							<li><a href="#">Fusce vitae dolor vitae blandit varius.</a></li>
							<li><a href="#">Proin commodo metus sed nisi lobortis.</a></li>
							<li><a href="#">Nunc volutpat neque vel augue interdum,</a></li>
							<li><a href="#">condimentum fringilla justo lobortis.</a></li>
							<li><a href="#">Vivamus consequat dolor ac est congue.</a></li>
						</ul>
					</div>
					<div class="col-md-4 about-choose-info">
						<h4>Our technologies</h4>
						<ul>
							<li><a href="#">Donec ut quam ligula feugiat scelerisque.</a></li>
							<li><a href="#">Etiam volutpat tortor quis nibh lobortis</a></li>
							<li><a href="#">Fusce vitae dolor vitae blandit varius.</a></li>
							<li><a href="#">Proin commodo metus sed nisi lobortis.</a></li>
							<li><a href="#">Nunc volutpat neque vel augue interdum,</a></li>
							<li><a href="#">condimentum fringilla justo lobortis.</a></li>
							<li><a href="#">Vivamus consequat dolor ac est congue.</a></li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>	
		</div>
	</div>	
	<!--//about-->
	<!--map  640  480-->
	<div class="map">
		<iframe src="https://www.google.com/maps/d/embed?mid=z-E17S2b2kao.kqEq9AvkB8kg" width="640" height="480"></iframe>
		<!--<div class="container">	
			<div class="map-info">
				<ul>
					<li>Head office</li>
					<li>Anore Road-22</li>
					<li>New York,USA-0000</li>
					<li>111 222 555</li>
				</ul>
			</div>-->
		</div>
	</div>
	<!--//map-->
	<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-grids">				
				<div class="col-md-4 recent-posts">
					<h4>Announcements</h4>
					<div class="recent-posts-text">
						<h5>
						<?php
						$result = mysql_query( "SELECT * FROM announce_remind WHERE `type` ='Announcement' ORDER BY `id` DESC LIMIT 4");
						while($row=mysql_fetch_array($result))
						{
						echo $row['eventdate'].'<br/><br/>';
						echo 'Title : '.$row['title'].'<br/><br/>';
						echo '<p style="color:gray;">'.$row['detail'].'</p>'.'<hr style="border: 1px dotted #eed0f5"/>';
						}
						?>
						</h5>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Reminders</h4>
					<div class="recent-posts-text">
						<h5>
						<?php
						$result = mysql_query( "SELECT * FROM announce_remind WHERE `type` ='Reminder' ORDER BY `id` DESC LIMIT 4");
						while($row=mysql_fetch_array($result))
						{
						echo $row['eventdate'].'<br/><br/>';
						echo 'Title : '.$row['title'].'<br/><br/>';
						echo '<p style="color:gray;">'.$row['detail'].'</p>'.'<hr style="border: 1px dotted #eed0f5"/>';
						}
						?>
						</h5>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Our address</h4>
					<p class="adrs">Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus,
						 facilisi Nam liber tempor cum soluta </p>
					<ul>
						<li><span></span>Moonshine St. 14/05 Light, Japan</li>
						<li><span class="ph-no"></span>+00 (123) 111 11 11</li>
						<li><span class="mail"></span><a href="mailto:example@mail.com">mail@example.com</a></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>	
	</div>	
	<!--//footer-->
	<div class="footer-bottom">
		<div class="container">
			<p>©Copyright | Design by <a href="#">SAO</a></p>
		</div>
	</div>
	<!--smooth-scrolling-of-move-up-->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!--//smooth-scrolling-of-move-up-->
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"> </script>
</body>
<!--Start Blocking the mouse-->
<body oncontextmenu="return false;">
<!--End Blocking the mouse-->
</html>