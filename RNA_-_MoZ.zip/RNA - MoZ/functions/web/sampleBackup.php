<?php 
//require('./login.php');
error_reporting(0);
?>
<html>
<head>
</head>

<body>
	<div class="section-login" >	
			<div id= "loginForm">
				<p style= "loginForm_p">Admin Login</p>	
					<!--<form action = "login.php" method = "post">
						<input id = "email" type = "text" name = "uname" style = "width: 300px" title = "User ID"><br/>
						<input id = "password" type = "password" name = "pass" style = "width: 300px" title = "Password"><br/>
						
						<input id = "submit" type = "submit" value = "Login" name = "submit" style = "width: 80px; height:50px; float:right; color: gray; font-weight: bold; margin-top:5px;">
					</form>	-->
				
					<?php
					//set username and password
					if (isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['middlename']) && isset($_POST['username']) && isset($_POST['password']) && isset($_POST['password_again']) /*&& isset($_POST['position'])*/){
						$username = $_POST['username'];
						$password = $_POST['password'];
						$password_again = $_POST['password_again'];
						//$password_hash = md5($password);
						$firstname = $_POST['firstname'];
						$lastname = $_POST['lastname'];
						$middlename = $_POST['middlename'];
						//$position = $_POST['position'];
										
						//md5 use for password encryption
						//get password encrypted from database
					
						//$password_hash = md5($password);
										
						if (!empty($firstname) && !empty($lastname) && !empty($middlename)){
										
							//Select data from database where username and the password is matched.
							$query = "SELECT `id` FROM admin WHERE `firstname`='".mysql_real_escape_string ($firstname)."' && `lastname` = '".mysql_real_escape_string($lastname)."' && `middlename` = '".mysql_real_escape_string($middlename)."'";
					 
							if ($query_run = mysql_query($query)){
								$query_num_rows = mysql_num_rows($query_run);
					
								if($query_num_rows == 0){
									echo "<p style='color: red;font-size:14px; width: auto;margin:auto;font-family: Roboto-Light;'>".'Invalid background info'."</p>";
								}else if ($query_num_rows == 1){
									/*//grab student id from database
									 $user_id = mysql_result($query_run, 0, 'id');
									//set session for logging in
									 $_SESSION['user_id'] = $user_id;
									 //relocate the location to index.php
									 header('Location: login.php');*/
									if (!empty($username) && !empty($password) && !empty($password_again)/*&& !empty($position)*/){
		
										if(strlen($username)<5){	//set required min length for username	
											echo 'Username must at least 5 characters or above.';
										}else{
											if($password != $password_again){ //confirm password
												echo 'Password not matched';
											}else{
												//registration process
												
												$query = "SELECT `username` FROM `register` WHERE `username` = '$username'"; //validation of username injection
												$query_run = mysql_query($query);
												
												if(mysql_num_rows($query_run) == 1){
													echo 'Username already exist';
												}else{
													$query = "INSERT INTO `register` VALUES ('".mysql_real_escape_string($username)."','".mysql_real_escape_string($password)."','".mysql_real_escape_string($firstname)."','".mysql_real_escape_string($lastname)."','".mysql_real_escape_string($middlename)."')";           
													
													if ($query_run = mysql_query($query)){
														//grab student id from database
														 $user_id = mysql_result($query_run, 0, 'id');
														//set session for logging in
														 $_SESSION['user_id'] = $user_id;
														 //relocate the location to index.php
														 header('Location: register_success.php');
													}else{
														echo 'Sorry we couldn\'t register you at this time. Try again';
													}
												}
											}
										}
									}else{
										echo 'All fields are required';
									}									 
									 
									 
								}
							}
						}else{
							echo "<p style='color: red;font-size:14px; width: auto;margin:auto;font-family: Roboto-Light;'>".'Please enter background info'."</p>";
						}	
					} 
				?>
				
				<form action = "<?php echo $current_file; ?>" method = "post">
					<input id = "firstname" type = "text" name = "firstname" style = "" title = "firstname" placeholder="First Name" value = "<?php if (isset($firstname)) { echo $firstname; } ?>"><br/><br/>
					<input id = "lastname" type = "text" name = "lastname" style = "" title = "lastname" placeholder="Last Name"value = "<?php if (isset($lastname)) { echo $lastname; } ?>"><br/><br/>
					<input id = "middlename" type = "text" name = "middlename" style = "" title = "middlename" placeholder="Middle Name" value = "<?php if (isset($middlename)) { echo $middlename; } ?>"><br/><br/>
					<input id = "email" type = "text" name = "username" style = "" title = "User ID" placeholder="Username" maxlength ="10" value = "<?php if (isset($username)) { echo $username; }?>"><br/><br/>
					<input id = "password" type = "password" name = "password" style = "" title = "Password" placeholder="Password" ><br/><br/>
					<input id = "passwordagain" type = "password" name = "password_again" style = "" title = "Password Again" placeholder="Confirm Pasword" ><br/><br/>
					
						<input id = "submit" type = "submit" value = "Register" name = "submit">
				</form>
			</div>			
		</div>
</body>
</html>