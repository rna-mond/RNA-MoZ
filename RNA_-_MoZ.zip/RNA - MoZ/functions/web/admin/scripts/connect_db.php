<?php
$connection = mysql_connect("localhost", "root", "") or die ("mysql connection failed");
$db = mysql_select_db("mytesting_db") or die ("database not exists");
?>