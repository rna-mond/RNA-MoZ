<?php
session_start();

$userid = $_SESSION['id'];
$username = $_SESSION['username'];
?>


<!DOCTYPE html>
<html>
<head>
<title>ESCL Website</title>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/admin_profile.css" type="text/css" rel="stylesheet" media="all">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Doctor Plus Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Custom Theme files -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script> 
<!-- //js -->	
<!-- start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>	
<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
</script>

<!--//end-smoth-scrolling-->

<script type="text/css">
	
</script>


</head>
<body>
	<!--header-->
	<div class="header">
		<div class="container">
			<div class="header-logo">
				<a href="index.html"><img src="images/logonew.png" alt="logo"/></a>					
			</div>
			<div class="clearfix-head"></div>
			<div class="header-info">
				<p><?php
						//if(loggedin()){
						//	$firstname = getuserfield('user_fname');
						//	$surname = getuserfield('user_lname');
						//	echo '<i><b>' .$firstname.' ' .$surname.'</i></b>';
						//}
				?></p>
				<h4>Admin</h4>
			</div>			
			<div class="clearfix"> </div>
		</div>	
	</div>
	<!--//header-->
	<!--header-bottom-->
	<div class="header-bottom">
		<div class="container">
			<!--top-nav-->
			<div class="top-nav cl-effect-5">
				<span class="menu-icon"><img src="images/menu-icon_new.png" alt=""/></span>		
				<ul class="nav1">
					<li><a href="login_admin.php" ><span data-hover="Dashboard">Dashboard</span></a></li>
					<li><a href="login_adminmembers.php" > <span data-hover="Patients">Patients</span></a></li>
					<li><a href="login_adminannouncement.php"> <span data-hover="Announcement">Announcement</span></a></li>
					<li><a href="login_adminreminders.php"> <span data-hover="Reminders">Reminders</span></a></li>
					<li><a href="login_admincalendar.php"> <span data-hover="Calendar">Calendar</span></a></li>
					<li><a class="active"> <span data-hover="Profile">Profile</span></a></li>
				</ul>
				<!-- script-for-menu -->
				<script>
				   $( "span.menu-icon" ).click(function() {
					 $( "ul.nav1" ).slideToggle( 300, function() {
					 // Animation complete.
					  });
					 });
				</script>
				<!-- /script-for-menu -->
			</div>
			
			<div class="customnav" style="">
				<ul class = "fname" style="">
					<li ><a  href="" >
					<?php
						$firstname = getuserfield('firstname');
						echo '<a> '.$firstname.'</a>';
					?> 
					</a></li>
				</ul>
						
				
				<!--<ul style="">    <img src="images/move-down.png" alt=""/>
					<li><a href="services.html"> <span data-hover="Services">
					<?php
					/*	$active = getuserfield('active');
						$firstname = getuserfield('firstname');
						
						//$count = mysql_query("");
						if ($active > 0){
							mysql_query("UPDATE login SET pagehits=pagehits+1 WHERE firstname = '$firstname'");
							
							$result = mysql_query("SELECT * FROM login WHERE firstname = '$firstname'");
								while($row = mysql_fetch_array($result)){
								$hits = $row['pagehits'];
							}
							echo '<a href = "logout.php"> '.$hits.'</a>';
						}
					*/
					?> 
					</span></a></li>
				</ul>-->
				
					<ul class = "logout_img">				
						<li>
							<a><img src="images/move-down.png" alt=""/></a>
							<ul  class = "logout_sub">
								<li>
									<li><a href="logout.php">Sign out</a></li>
								</li>
							</ul>
						</li>
						
					</ul>
			</div>
			<!--//top-nav-->
			<!--<form class="navbar-form navbar-right">
				<div class="form-group">
					<input type="text" class="form-control" placeholder="Search">
					<button type="submit" class="btn btn-default"></button>
				</div>		
			</form>-->
			<div class="clearfix"> </div>
			
		</div>
	</div>
	

	<!--profile-->
	<div class="profile">
		
	
		<div class="profile_container">
			<div class="profile_title">
			Personal Information -
			
			<?php $id = getuserfield('ap_id');  
								echo "ID No : ".$id; ?>
			</div>
			
			<div class="profile_content">
				
				
			
				<form action="admin_profile.php" action="POST">
						<table id="ResponsiveTable">
							<tr id="HeadRow">
								<td></td>	
								<td>ID</td>	
								<td>Last Name</td>	
								<td>First Name</td>	
								<td>Middle Name</td>
								<td>Username</td>
								<td>Password</td>
								<td></td>
								<!--<td>Record</td>
									<th><?php //echo $fname; ?></th>-->
							</tr>
							<?php
				
							$id = getuserfield('ap_id');						
							$query =mysql_query("SELECT * FROM `patient_geninfo`,`login` WHERE login.ap_id = '$id' AND patient_geninfo.patientID = login.ap_id");
							
								while($row=mysql_fetch_array($query))							
								{
									$lname = $row['ap_id'];
									$lname = $row['lastname'];
									$fname = $row['firstname'];
									$mname = $row['middlename'];
									$username = $row['username'];
									$password = $row['password'];
									$ap_id = $row['ap_id'];
									
								?>
								
								<tr>
										<td tableHeadData="Contact"></td>
										<td tableHeadData="Contact"><?php echo $ap_id; ?></td>
										<td tableHeadData="Last Name"><?php echo $lname; ?></td>
										<td tableHeadData="First Name"><?php echo $fname; ?></td>
										<td tableHeadData="Middle Name"><?php echo $mname; ?></td>
										<td tableHeadData="Contact"><?php echo $username; ?></td>
										<td tableHeadData="Contact"><?php echo $password; ?></td>
										<!--<td><input type="submit" name="update "value="Update"/></td>-->
									
								</tr>	
									<?php
								}
							?>
						</table>
				</form>	
			</div>
		</div>
	</div>
	<!--//profile-->
	<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-grids">				
				<div class="col-md-4 recent-posts">
					<h4>Announcements</h4>
					<div class="recent-posts-text">
						<h5>
						<?php
						$result = mysql_query( "SELECT * FROM announce_remind WHERE `type` ='Announcement' ORDER BY `id` DESC LIMIT 4");
						while($row=mysql_fetch_array($result))
						{
						echo $row['eventdate'].'<br/><br/>';
						echo 'Title : '.$row['title'].'<br/><br/>';
						echo '<p style="color:gray;">'.$row['detail'].'</p>'.'<hr style="border: 1px dotted #eed0f5"/>';
						}
						?>
						</h5>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Reminders</h4>
					<div class="recent-posts-text">
						<h5>
						<?php
						$result = mysql_query( "SELECT * FROM announce_remind WHERE `type` ='Reminder' ORDER BY `id` DESC LIMIT 4");
						while($row=mysql_fetch_array($result))
						{
						echo $row['eventdate'].'<br/><br/>';
						echo 'Title : '.$row['title'].'<br/><br/>';
						echo '<p style="color:gray;">'.$row['detail'].'</p>'.'<hr style="border: 1px dotted #eed0f5"/>';
						}
						?>
						</h5>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Reminders</h4>
					<div class="recent-posts-text">
						<h5>about 2 days ago<span>@kristit</span></h5>
						<p>Good work buddy</p>
					</div>
					<div class="recent-posts-text">
						<h5>about 2 days ago <span>@fasteven</span></h5>
						<p>Good work buddy</p>
					</div>
					<div class="recent-posts-text">
						<h5>about 2 days ago <span>@streamer</span> </h5>
						<p>Good work buddy</p>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>	
	</div>	
	<!--//footer-->
	<div class="footer-bottom">
		<div class="container">
			<p>©Copyright | Design by <a href="#">SAO</a></p>
		</div>
	</div>
	<!--smooth-scrolling-of-move-up-->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!--//smooth-scrolling-of-move-up-->
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"> </script>
</body>
</html>		








