<?php
session_start();

$userid = $_SESSION['id'];
$username = $_SESSION['username'];

$queryData = mysql_query("SELECT * FROM announce_remind WHERE type = 'Reminder' ORDER BY dateadded DESC LIMIT 10") or die(mysql_error());

if(isset($_GET['delete'])){
	
	$multiple = $_GET['multiple'];
	
	$i = 0;
	
	$sql = "DELETE FROM announce_remind";
	
	foreach($multiple as $item_id){
		$i ++;
		
		if($i == 1){
			$sql .= " WHERE id = ".mysql_real_escape_string($item_id) ."";
		
		}else{
			$sql .= " OR id = ".mysql_real_escape_string($item_id) ."";
		}
	}
	mysql_query($sql) or die(mysql_error());
	
	header("location: " .$_SERVER['PHP_SELF']);
	
	exit();
}


?>


<!DOCTYPE html>
<html>
<head>
<title>ESCL Website</title>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/admin_profile.css" type="text/css" rel="stylesheet" media="all">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Doctor Plus Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Custom Theme files -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script> 
<!-- //js -->	
<!-- start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>	
<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
</script>

<!--//end-smoth-scrolling-->
<style type="text/css">
	body{
	}
	
	#wrapper{
			margin: 0 auto;
			width: 650px;
	}
	
	.profile_content td{
		padding:10px;
		border-bottom: 1px solid #dfe3ee;
		text-indent: 10px;
		color: gray;
	}
	
	.profile_content thead{
		background:#dfe3ee;
		color: gray;
		font-weight: bold;
	}
	.profile_content h2{
		text-align: center;
		padding: 10px;
		color: gray;
	}
	</style>


</head>
<body>
	<!--header-->
	<div class="header">
		<div class="container">
			<div class="header-logo">
				<a href="index.html"><img src="images/logonew.png" alt="logo"/></a>					
			</div>
			<div class="clearfix-head"></div>
			<div class="header-info">
				<p><?php
						//if(loggedin()){
						//	$firstname = getuserfield('user_fname');
						//	$surname = getuserfield('user_lname');
						//	echo '<i><b>' .$firstname.' ' .$surname.'</i></b>';
						//}
				?></p>
				<h4>Admin</h4>
			</div>			
			<div class="clearfix"> </div>
		</div>	
	</div>
	<!--//header-->
	<!--header-bottom-->
	<div class="header-bottom">
		<div class="container">
			<!--top-nav-->
			<div class="top-nav cl-effect-5">
				<span class="menu-icon"><img src="images/menu-icon_new.png" alt=""/></span>		
				<ul class="nav1">
					<li><a href="login_patient.php" ><span data-hover="Dashboard">Dashboard</span></a></li>
					<li><a href="login_patientannouncement.php" > <span data-hover="Announcement">Announcement</span></a></li>
					<li><a class="active"> <span data-hover="Reminders">Reminders</span></a></li>
					<li><a href="about.html"> <span data-hover="My Profile">My Profile</span></a>
					<li>
						<?php
							echo '<a href = "logout.php" style="list-style-type: none; display: inline-block; "><span data-hover="Logout">Logout</span></a> <br>';
						?>			
					</li>
				</ul>
				<!-- script-for-menu -->
				<script>
				   $( "span.menu-icon" ).click(function() {
					 $( "ul.nav1" ).slideToggle( 300, function() {
					 // Animation complete.
					  });
					 });
				</script>
				<!-- /script-for-menu -->
			</div>
			
			<div class="customnav" style="">
				<ul class = "fname" style="">
					<li ><a  href="" >
					<?php
						$firstname = getuserfield('firstname');
						echo '<a> Welcome : </a>' .'<a>'.$firstname.'</a>';
					?> 
					</a></li>
				</ul>
						
				
				<!--<ul style="">    <img src="images/move-down.png" alt=""/>
					<li><a href="services.html"> <span data-hover="Services">
					<?php
					/*	$active = getuserfield('active');
						$firstname = getuserfield('firstname');
						
						//$count = mysql_query("");
						if ($active > 0){
							mysql_query("UPDATE login SET pagehits=pagehits+1 WHERE firstname = '$firstname'");
							
							$result = mysql_query("SELECT * FROM login WHERE firstname = '$firstname'");
								while($row = mysql_fetch_array($result)){
								$hits = $row['pagehits'];
							}
							echo '<a href = "logout.php"> '.$hits.'</a>';
						}
					*/
					?> 
					</span></a></li>
				</ul>
				
					<ul class = "logout_img">				
						<li>
							<a><img src="images/move-down.png" alt=""/></a>
							<ul  class = "logout_sub">
								<li>
									<li><a href="logout.php">Sign out</a></li>
								</li>
							</ul>
						</li>
						
					</ul>-->
			</div>
			<!--//top-nav-->
			<!--<form class="navbar-form navbar-right">
				<div class="form-group">
					<input type="text" class="form-control" placeholder="Search">
					<button type="submit" class="btn btn-default"></button>
				</div>		
			</form>-->
			<div class="clearfix"> </div>
			
		</div>
	</div>
	

	<!--profile-->
	<div class="profile">
		
	
		<div class="profile_container">
			<div class="profile_title">
			Lists of Reminders
			</div>
			
			<div class="profile_content">
				<?php if(mysql_num_rows($queryData) > 0): ?>
					<!--Display Data-->
					<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="Get">
						<table width="100%">
							<thead>
								<tr>
									<td>Title</td>
									<td>Detail</td>
									<td>Event Date</td>
									<td>Date Added</td>
								</tr>
							</thead>
							
							<tbody>
								<?php // opern while syntax
								while($row=mysql_fetch_assoc($queryData)) 
								{
									
								?>
								<tr>
									<td><?php echo $row['title']; ?></td>
									<td><?php echo $row['detail']; ?></td>
									<td><?php echo $row['eventdate']; ?></td>
									<td><?php echo $row['dateadded']; ?></td>
								</tr>
								<?php 
								} //close while syntax
								?>
							</tbody>
						</table>
					</form>
					<?php else: ?>
					<h2>No Announcement yet!</h2>
					<?php endif; ?>	
			</div>
		</div>
	</div>
	
	<script type="text/javascript">
		var toggle = document.getElementById('toggle');
		
		toggle.onclick = function()
		{
			var multiple = document.getElementsByName('multiple[]');
			
			for (i = 0; i < multiple.length; i++){
				multiple[i].checked = this.checked;
			}
		}
	</script>
	<!--//profile-->
	<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-grids">				
				<div class="col-md-4 recent-posts">
					<h4>Announcements</h4>
					<div class="recent-posts-text">
						<h5>
						<?php
						$result = mysql_query( "SELECT * FROM announce_remind WHERE `type` ='Announcement' ORDER BY `id` DESC LIMIT 4");
						while($row=mysql_fetch_array($result))
						{
						echo $row['eventdate'].'<br/><br/>';
						echo 'Title : '.$row['title'].'<br/><br/>';
						echo '<p style="color:gray;">'.$row['detail'].'</p>'.'<hr style="border: 1px dotted #eed0f5"/>';
						}
						?>
						</h5>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Reminders</h4>
					<div class="recent-posts-text">
						<h5>
						<?php
						$result = mysql_query( "SELECT * FROM announce_remind WHERE `type` ='Reminder' ORDER BY `id` DESC LIMIT 4");
						while($row=mysql_fetch_array($result))
						{
						echo $row['eventdate'].'<br/><br/>';
						echo 'Title : '.$row['title'].'<br/><br/>';
						echo '<p style="color:gray;">'.$row['detail'].'</p>'.'<hr style="border: 1px dotted #eed0f5"/>';
						}
						?>
						</h5>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Our address</h4>
					<p class="adrs">Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus,
						 facilisi Nam liber tempor cum soluta </p>
					<ul>
						<li><span></span>Moonshine St. 14/05 Light, Japan</li>
						<li><span class="ph-no"></span>+00 (123) 111 11 11</li>
						<li><span class="mail"></span><a href="mailto:example@mail.com">mail@example.com</a></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>	
	</div>	
	<!--//footer-->
	<div class="footer-bottom">
		<div class="container">
			<p>©Copyright | Design by <a href="#">SAO</a></p>
		</div>
	</div>
	<!--smooth-scrolling-of-move-up-->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!--//smooth-scrolling-of-move-up-->
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"> </script>
</body>
</html>		








