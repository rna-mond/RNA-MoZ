<?php 
error_reporting(E_ALL ^ E_DEPRECATED);

$msg = "";
if(isset($_GET['msg'])){
	$msg = $_GET['msg'];
	$msg = strip_tags($msg);
	$msg = addslashes($msg);
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Quiz Tut</title>
<script>
function startQuiz(url){
	window.location = url;
}
</script>
</head>
<body>
<?php echo $msg; ?>
<h3>Survey Form</h3>
<button onClick="startQuiz('quiz.php?question=1')">Click Here To Begin</button>
</body>
</html>