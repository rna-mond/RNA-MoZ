<?php
session_start();

$userid = $_SESSION['id'];
$username = $_SESSION['username'];
?>


<!DOCTYPE html>
<html>
<head>
<title>ESCL Website</title>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/admin_calendar.css" type="text/css" rel="stylesheet" media="all">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Doctor Plus Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Custom Theme files -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script> 
<!-- //js -->	
<!-- start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>	
<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
</script>

<script type="text/javascript">
	function preventBack(){
		window.history.forward();
	}
	setTimeout("preventBack()",0);
	window.onunload = function() { null };
	
	/*
	window.onbeforeunload = function(){
		return "You cant be back";
	}
	*/
</script>

<!--//end-smoth-scrolling-->
<!--calendar-->
  <script> //function to set date, month and year
   function goLastMonth(month, year){
    if(month == 1) {
     --year;
     month = 13;
    }
    --month
    var monthstring = ""+month+"";
    var monthlength = monthstring.length;
    if(monthlength <=1){
     monthstring = "0" + monthstring;
    }
    document.location.href = "<?php $_SERVER['PHP_SELF'];?>?month="+monthstring+"&year="+year;
   }
   function goNextMonth(month, year){
    if(month == 12) {
     ++year;
     month = 0;
    }
    ++month
    var monthstring = ""+month+"";
    var monthlength = monthstring.length;
    if(monthlength <=1){
     monthstring = "0" + monthstring;
    }
    document.location.href = "<?php $_SERVER['PHP_SELF'];?>?month="+monthstring+"&year="+year;
   }
  </script>
  
  <style type="text/css"> 
	
			.event{
				background-color : #E6E6FA;
			}
			
			.today{
				background-color : #d1e7ff;
			}
			
		 </style>
	
<!--//calendar-->

</head>
<body>
	<!--header-->
	<div class="header">
		<div class="container">
			<div class="header-logo">
				<a href="index.html"><img src="images/logonew.png" alt="logo"/></a>					
			</div>
			<div class="clearfix-head"></div>
			<div class="header-info">
				<p><?php
						//if(loggedin()){
						//	$firstname = getuserfield('user_fname');
						//	$surname = getuserfield('user_lname');
						//	echo '<i><b>' .$firstname.' ' .$surname.'</i></b>';
						//}
				?></p>
				<h4>Admin</h4>
			</div>			
			<div class="clearfix"> </div>
		</div>	
	</div>
	<!--//header-->
	<!--header-bottom-->
	<div class="header-bottom">
		<div class="container">
			<!--top-nav-->
			<div class="top-nav cl-effect-5">
				<span class="menu-icon"><img src="images/menu-icon_new.png" alt=""/></span>		
				<ul class="nav1">
					<li><a href="login_admin.php" ><span data-hover="Dashboard">Dashboard</span></a></li>
					<li><a href="login_adminmembers.php"> <span data-hover="Patients">Patients</span></a></li>
					<li><a href="login_adminannouncement.php"> <span data-hover="Announcement">Announcement</span></a></li>
					<li><a href="login_adminreminders.php"> <span data-hover="Reminders">Reminders</span></a></li>
					<li><a class="active"> <span data-hover="Calendar">Calendar</span></a></li>
				
				</ul>
				<!-- script-for-menu -->
				<script>
				   $( "span.menu-icon" ).click(function() {
					 $( "ul.nav1" ).slideToggle( 300, function() {
					 // Animation complete.
					  });
					 });
				</script>
				<!-- /script-for-menu -->
			</div>
			
			<div class="customnav" style="">
				<ul class = "fname" style="">
					<li ><a  href="" >
					<?php
						$firstname = getuserfield('firstname');
						echo '<a href = "login_adminprofile.php"> '.$firstname.'</a>';
					?> 
					</a></li>
				</ul>
						
				
				<!--<ul style="">    <img src="images/move-down.png" alt=""/>
					<li><a href="services.html"> <span data-hover="Services">
					<?php
					/*	$active = getuserfield('active');
						$firstname = getuserfield('firstname');
						
						//$count = mysql_query("");
						if ($active > 0){
							mysql_query("UPDATE login SET pagehits=pagehits+1 WHERE firstname = '$firstname'");
							
							$result = mysql_query("SELECT * FROM login WHERE firstname = '$firstname'");
								while($row = mysql_fetch_array($result)){
								$hits = $row['pagehits'];
							}
							echo '<a href = "logout.php"> '.$hits.'</a>';
						}
					*/
					?> 
					</span></a></li>
				</ul>-->
				
					<ul class = "logout_img">				
						<li>
							<a><img src="images/move-down.png" alt=""/></a>
							<ul  class = "logout_sub">
								<li>
									<li><a href="logout.php">Sign out</a></li>
								</li>
							</ul>
						</li>
						
					</ul>
			</div>
			<!--//top-nav-->
			<!--<form class="navbar-form navbar-right">
				<div class="form-group">
					<input type="text" class="form-control" placeholder="Search">
					<button type="submit" class="btn btn-default"></button>
				</div>		
			</form>-->
			<div class="clearfix"> </div>
			
		</div>
	</div>
	

	<!--profile-->
	<div class="calendar">
		
	
		<div class="calendar_container">
			<div class="calendar_title">
			Announcement / Reminders
			</div>
			
			
			<div class="calendar_content">
				<script type="text/javascript">
		
					tday=new Array("(Sun)","(Mon)","(Tue)","(Wed)","(Thur)","(Fri)","(Sat)");
					tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

					function GetClock(){
					var d=new Date();
					var nday= d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear(),nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

					 if(nhour==0){ap=" AM";nhour=12;}
						else if(nhour<12){ap=" AM";}
						else if(nhour==12){ap=" PM";}
						else if(nhour>12){ap=" PM";nhour-=12;}

					if(nyear<1000) nyear+=1900;
					if(nmin<=9) nmin="0"+nmin;
					if(nsec<=9) nsec="0"+nsec;

						document.getElementById('clockbox').innerHTML=" "+"<p style='color: #2e78ae; '>"+" "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+tday[nday]+" @ "+nhour+":"+nmin+":"+nsec+ap+""+"</p>";
						}

						window.onload=function(){
						GetClock();
						setInterval(GetClock,1000);
						}
				</script><!--End Clock-->
				
				<div id="clockbox" style = "font-size: 15px;  float: left;  margin-bottom:20px; width: 500px; "></div>
				
				<br>	
				 <?php
				   //get current date or specific month and year
				   if (isset($_GET['day'])){
					$day = $_GET['day'];
				   } else {
					$day = date("d");
				   }
				   if(isset($_GET['month'])){
					$month = $_GET['month'];
				   } else {
					$month = date("m");
				   }
				   if(isset($_GET['year'])){
					$year = $_GET['year'];
				   }else{
					$year = date("Y");
				   }
					
					//get date data for display such as month name
				   $currentTimeStamp = strtotime( "$day-$month-$year");
				   $monthName = date("F", $currentTimeStamp);
				   $numDays = date("t",$currentTimeStamp);
				   $counter = 0;
				  ?>
				  
				  <?php //insert data to database
					
					if(!empty($_POST)){
						if(isset($_GET['add'])){
						$type =$_POST['txttype'] ;
						$title =$_POST['txttitle'] ;
						$detail =$_POST['txtdetail'];
						$eventdate = $month."/".$day."/".$year;
						
							if(!empty($title) && !empty($detail)){
							$sqlinsert = "INSERT into announce_remind(title,detail,type,eventdate,dateadded) values ('".$title."','".$detail."','".$type."','".$eventdate."', NOW())";
							$resultinginsert = mysql_query($sqlinsert);
							
								if($resultinginsert ){
								echo "Successfully added...";
								}
							}
						}
					}
						?>
				  <!--shows full calendarofevents--> 
				  <table border="1px" cellpadding="0px" cellspacing="0px"> 
				   <tr>
					<td align="center">
					 <input style='width:100px;' type='button' value='Prev'name='previousbutton' onclick ="goLastMonth(<?php echo $month.','.$year?>)">
					</td>
					<td align="center" colspan="5" style="font-size: 20px;"><?php echo $monthName." ".$year; ?></td>
					<td align="center">
					 <input style='width:100px;' type='button' value='Next'name='nextbutton' onclick ="goNextMonth(<?php echo $month.','.$year?>)">
					</td>
				   </tr>
				   <tr>
					<td align="center" width='100px'>Sunday</td>
					<td align="center" width='100px'>Monday</td>
					<td align="center" width='100px'>Tuesday</td>
					<td align="center" width='100px'>Wednesday</td>
					<td align="center" width='100px'>Thursday</td>
					<td align="center" width='100px'>Friday</td>
					<td align="center" width='100px'>Saturday</td>
				   </tr>
				   
				  
				   
				   <?php
						echo "<tr'>";
						for($i = 1; $i < $numDays+1; $i++, $counter++){
						$timeStamp = strtotime("$year-$month-$i");
						if($i == 1) {
						$firstDay = date("w", $timeStamp);
						for($j = 0; $j < $firstDay; $j++, $counter++) {
						echo "<td>&nbsp;</td>";
						}
						}
						if($counter % 7 == 0) {
						echo"</tr><tr>";
						}
						$monthstring = $month;
						$monthlength = strlen($monthstring);
						$daystring = $i;
						$daylength = strlen($daystring);
						if($monthlength <= 1){
						$monthstring = "0".$monthstring;
						}
						if($daylength <=1){
						$daystring = "0".$daystring;
						}
						$todaysDate = date("m/d/Y");
						$dateToCompare = $monthstring. '/' . $daystring. '/' . $year;
						echo "<td align='center'";
						if ($todaysDate == $dateToCompare){
						echo "class ='today'";
						} else{
						$sqlCount = "select * from announce_remind where eventdate='".$dateToCompare."' ";
						$noOfEvent = mysql_num_rows(mysql_query($sqlCount));
						if($noOfEvent >= 1){
						echo "class='event'";
						}
						}
						echo "><a href='".$_SERVER['PHP_SELF']."?month=".$monthstring."&day=".$daystring."&year=".$year."&v=true'>".$i."</a></td>";
						}
						echo "</tr>";
				?>
				</table><!--end of full calendarofevents--> 
				 
					
					 <?php //get all data from data base and show in php
						if(isset($_GET['v'])) {
									
									echo "<a href='".$_SERVER['PHP_SELF']."?month=".$month."&day=".$day."&year=".$year."&v=true&f=true' style = 'font-size: 17px; text-decoration: underline; '>Add Announcement / Reminders</a>";
									echo "<br><br>";
									
										if(isset($_GET['f'])) {
										echo "<div style='width: 400px; height:130px; padding: 20px 0px 20px 0px; '>";
										include("eventform.php");
									echo "</div>";
							
						}
						//ORDER BY `id` DESC - use to get the latest data inserted from database
						// try  text-decoration: underline; text-decoration-style: dashed; -moz-text-decoration-color: #b3bbc6
						$sqlEvent = "select * from announce_remind where eventdate='".$month."/".$day."/".$year."' ORDER BY `id` DESC LIMIT 5";
						
						$resultEvents = mysql_query($sqlEvent);
						
						echo "<p style = 'font-size: 20px; margin-top: 90px; text-align: center;  -moz-text-decoration-color: #8f9aa8; color:#3b5998;'>List of announcements / reminders</p>";
							echo "<div style='width: 720px; border-top:1px solid #dfe3ee; '>";
							
								while ($events = mysql_fetch_array($resultEvents)){
									echo "<br>";
									echo "Posted as : ".$events['type']."<br>";
									echo "Date Posted : ".$events['dateadded']."<br>";
									echo "Title : 			".$events['title']."<br>";
									echo "Details : "."<br>";
									echo $events['detail']."<br><hr style='border-color: #dfe3ee;'>";
									}
								}
							echo "</div>";
					?>
									
				<br style="clear: left;" /><!--note 'Do not delete'-->
				
			</div>
		</div>
	</div>
	<!--//profile-->
	<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-grids">				
				<div class="col-md-4 recent-posts">
					<h4>Announcements</h4>
					<div class="recent-posts-text">
						<h5>
						<?php
						$result = mysql_query( "SELECT * FROM announce_remind WHERE `type` ='Announcement' ORDER BY `id` DESC LIMIT 4");
						while($row=mysql_fetch_array($result))
						{
						echo $row['eventdate'].'<br/><br/>';
						echo 'Title : '.$row['title'].'<br/><br/>';
						echo '<p style="color:gray;">'.$row['detail'].'</p>'.'<hr style="border: 1px dotted #eed0f5"/>';
						}
						?>
						</h5>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Reminders</h4>
					<div class="recent-posts-text">
						<h5>
						<?php
						$result = mysql_query( "SELECT * FROM announce_remind WHERE `type` ='Reminder' ORDER BY `id` DESC LIMIT 4");
						while($row=mysql_fetch_array($result))
						{
						echo $row['eventdate'].'<br/><br/>';
						echo 'Title : '.$row['title'].'<br/><br/>';
						echo '<p style="color:gray;">'.$row['detail'].'</p>'.'<hr style="border: 1px dotted #eed0f5"/>';
						}
						?>
						</h5>
					</div>
				</div>
				<div class="col-md-4 recent-posts">
					<h4>Reminders</h4>
					<div class="recent-posts-text">
						<h5>about 2 days ago<span>@kristit</span></h5>
						<p>Good work buddy</p>
					</div>
					<div class="recent-posts-text">
						<h5>about 2 days ago <span>@fasteven</span></h5>
						<p>Good work buddy</p>
					</div>
					<div class="recent-posts-text">
						<h5>about 2 days ago <span>@streamer</span> </h5>
						<p>Good work buddy</p>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>	
	</div>	
	<!--//footer-->
	<div class="footer-bottom">
		<div class="container">
			<p>©Copyright | Design by <a href="#">SAO</a></p>
		</div>
	</div>
	<!--smooth-scrolling-of-move-up-->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!--//smooth-scrolling-of-move-up-->
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"> </script>
</body>
</html>		








