<?php
error_reporting(0);
session_start();

?>

<!DOCTYPE html />

<html>

<head>
	<title>ESCL Website</title>
	<link href="css/register.css" type="text/css" rel="stylesheet" media="all">
	<!-- Custom Theme files -->
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Doctor Plus Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
		Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- //Custom Theme files -->
	<!-- js -->
	<script src="js/jquery-1.11.1.min.js"></script> 
	<!-- //js -->	
	<!-- start-smoth-scrolling-->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>	
	<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
	</script>
	
	<script type="text/javascript">
	function preventBack(){
		window.history.forward();
	}
	setTimeout("preventBack()",0);
	window.onunload = function() { null };
	
	/*
	window.onbeforeunload = function(){
		return "You cant be back";
	}
	*/
</script>
</head>

<body>

	<?php
	/*	if(!empty($_SERVER["HTTP_CLIENT_IP"])){
			$ip_address = $_SERVER["HTTP_CLIENT_IP"];
		}
		elseif(!empty($_SERVER["HTTP_X_FORWARDED_FOR"])){
			$ip_address = $_SERVER["HTTP_X_FORWARDED_FOR"];
		}
		else{
		$ip_address = $_SERVER["REMOTE_ADDR"];
		}		
		echo $ip_address;*/
	?>
	
	<?php
		
		
	?>
	
	<?php 
	
	
	if($_POST['registerbtn']){
		//allow check existence value from password and etc
		$getuser = $_POST['user'];
		$getemail = $_POST['email'];
		$getpass = $_POST['pass'];
		$getretypepass = $_POST['retypepass'];
		$getapid = $_POST['ap_id'];
		$getfname = $_POST['fname'];
		$getlname = $_POST['lname'];
		$getmname = $_POST['mname'];
		$getdesignation = $_POST['designation'];
		
		if($getuser){
			if ($getemail){
				if($getpass){
					if($getretypepass){
						if($getapid){
							if($getfname){
								if($getlname){
									if($getmname){
										if($getdesignation){
											if($getpass === $getretypepass){
												if( (strlen($getemail) >= 7) && (strstr($getemail, "@")) && (strstr($getemail, ".")) ){
													require '../db/connection.inc.php';
													
													$queryName = mysql_query("SELECT * FROM register WHERE ap_id = '$getapid' && firstname = '$getfname' && lastname = '$getlname' && middlename = '$getmname' && designation = '$getdesignation'");
													$Namerows = mysql_num_rows($queryName);
													
													if($Namerows == 1){
														
														$query = mysql_query("SELECT * FROM login WHERE username = '$getuser'");
														$numrows = mysql_num_rows($query);
														
														if($numrows == 0){
															$query = mysql_query("SELECT * FROM login WHERE email = '$getemail'");
															$numrows = mysql_num_rows($query);
															
															if($numrows == 0){
																$query = mysql_query("SELECT * FROM login WHERE  ap_id = '$getapid' && firstname = '$getfname' && lastname = '$getlname' && middlename = '$getmname' && designation = '$getdesignation'");
																$numrows = mysql_num_rows($query);
																
																if($numrows == 0){
																		$password = $getpass;
																		$date = date("F d, Y"); 
																		$code = md5(rand());
																		
																		mysql_query("INSERT INTO login VALUES('', '$getapid', '$getuser', '$password', '$getfname', '$getlname', '$getmname', '$getemail', '$getdesignation', '1', '$code', '$date', '1')");
																		
																		$errormsg = "You can now login.";
																}else
																	$errormsg = "Creating another account is not valid! Contact ESCL.";	
															}else
																$errormsg = "email already exit";	
														}else
															$errormsg = "username already exit";	
													}else	
														$errormsg = "Invalid account";														
												mysql_close();
												
												}else
													$errormsg = "Invalid e-mail account!";
											}else
												$errormsg = "Password not matched account!";
										}else
											$errormsg = "Invalid designation type register";
									}else
										$errormsg = "You must fill middle name field to register";
								}else
									$errormsg = "You must fill last name field to register";
							}else
								$errormsg = "You must fill first name field to register";
						}else
							$errormsg = "You must fill valid Admin/Patient ID to register";
					}else
						$errormsg = "You must retype your password to register";
				}else
					$errormsg = "You must enter password to register";
			}else
				$errormsg = "You must enter email to register";
		}else
			$errormsg = "You must enter username to register";
	}
	//<input type='text' id='mname' name='mname' value='' size='25' style ='text-transform:uppercase' />
	
	$form ="<form action ='register.php' method = 'post' class='registration_form'>
			
			 
			 <fieldset>
				<legend>Registration Form </legend>

				<p>Create A new Account <span>Already a member? <a href='login.php'>Log in</a></span> </p>
				
				<div id='list2'> <h3>$errormsg</h3></div>
				
				<div class='elements'>
				  <label for='name'>Username :</label>
				  <input type='text' id='name' name='user' value='$getuser' size='25' />
				</div>
				
				<div class='elements'>
				  <label for='e-mail'>E-mail :</label>
				  <input type='text' id='e-mail' name='email' value='$getemail' size='25' />
				</div>
				
				<div class='elements'>
				  <label for='Password'>Password :</label>
				  <input type='password' id='Password' name='pass' value='' size='25' />
				</div>
				
				<div class='elements'>
				  <label for='Retypepassword'>Retype password :</label>
				  <input type='password' id='Retypepassword' name='retypepass' value='' size='25' />
				</div>
				
				<div class='elements'>
				  <label for='apid'>Patient / Admin ID :</label>
				  <input type='text' id='ap_id' name='ap_id' value='' size='25' style ='text-transform:uppercase'/>
				</div>
				
				<div class='elements'>
				  <label for='firstname'>First Name :</label>
				  <input type='text' id='fname' name='fname' value='' size='25' style ='text-transform:uppercase' />
				</div>
				
				<div class='elements'>
				  <label for='lastname'>Lastname :</label>
				  <input type='text' id='lname' name='lname' value='' size='25'  style ='text-transform:uppercase' />
				</div>
				
				<div class='elements'>
				  <label for='middlename'>Middlename :</label>
				  <input type='text' id='mname' name='mname' value='' size='25' style ='text-transform:uppercase' />
				</div>
				
				<div class='elements'>
				  <label for='RegisteredAs'>Register as :</label>
				  <select id='designation' name='designation' style='width: 210px' >
					 <option value=''></option>
					 <option value='PATIENT'>PATIENT</option>
					 <option value='ADMIN'>ADMIN</option>
				  </select>
				</div>
				
				<div class='submit'>
				  <input type='submit' name='registerbtn' value='Register' />
				</div>
				
			 </fieldset>
			
			
			</form>";
			
		echo $form;
	?>
	
	<script type="text/javascript">
	$(function(){ 
		$('#list2').click(function(){ 
			$(this).toggleClass('clicked')
					
		}) 
	});
	</script>
</body>

</html>