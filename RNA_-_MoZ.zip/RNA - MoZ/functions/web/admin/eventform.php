
<!DOCTYPE html>
<html>
	<head>
	<link href="css/admin_calendar.css" type="text/css" rel="stylesheet" media="all">
	</head>
	<body>
	
	<form id="frm_eventform" name = "eventform" method="post" action ="<?php $_SERVER['PHP_SELF'];?>?month=<?php echo $month;?>&day=<?php echo $day;?>&year=<?php echo $year;?>&v=true&add=true">
			<table id="tbl_eventform" >
				<tr>
					<th >Select : </th>
					<td>
						<select id = "select" name = "txttype">
						  <option value="" ></option>
						  <option value="Announcement" >Announcement</option>
						  <option value="Reminder" >Reminder</option>
						</select>
					</td>
				</tr>
			
				<tr>
					<th >Title : </th>
					<td><input type="text" name="txttitle" size="50"></td>
				</tr>
			
				<tr>
					<th >Details:</th>
					<td><textarea name="txtdetail" rows="4" cols="50"></textarea></td>
				</tr>
				<tr>
					<th ></th>
					<td><input type="submit" name="btnadd" value="Save"></td>
				</tr>
			</table>
	</form>
	
	</body>
</html>