<?php
error_reporting(0);
require '../db/core.inc.php';
require '../db/connection.inc.php';


	//$firstname = getuserfield('user_fname');
	//$surname = getuserfield('user_lname');
	//echo 'WELCOME: '.' '.'<i><b>' .$firstname.' ' .$surname.'</i></b>'.' '.' <a href = "logout.php"> Log out </a> <br>';
	//include 'guesthome.php'; 
	
	//include_once 'loginform.inc.php'; 
	include_once 'registers.php'; 

?>



